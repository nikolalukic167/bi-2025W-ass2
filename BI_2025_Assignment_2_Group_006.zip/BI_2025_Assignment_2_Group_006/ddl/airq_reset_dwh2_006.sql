-- -------------------------------
-- 1) Assignment 1: create/reset dwh2_xxx schema per group
-- -------------------------------
DROP SCHEMA IF EXISTS dwh2_006 CASCADE;
CREATE SCHEMA dwh2_006 AUTHORIZATION grp_006;
