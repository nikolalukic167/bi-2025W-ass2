-- -------------------------------
-- 1) Assignment 1: create/reset stg2_xxx schema per group
-- -------------------------------
DROP SCHEMA IF EXISTS stg2_006 CASCADE;
CREATE SCHEMA stg2_006 AUTHORIZATION grp_006;